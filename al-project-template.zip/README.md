# 🧩 AL Project Template for Dynamics 365 Business Central

This repository provides a clean and reusable template for building **AL (Application Language)** projects for Microsoft **Dynamics 365 Business Central**.

---

## 📁 Folder Structure & Contents

- `.vscode/` – VS Code launch and debug configurations (`launch.json`)
- `.alcache/` – Cache folder (auto-generated, should be ignored)
- `.alpackages/` – AL symbol reference packages
- `.snapshots/` – App snapshots during publishing
- `.output/` – Folder for compiled `.app` files and other build outputs

---

## 📦 Ignored Files & Extensions

This repository includes a pre-configured `.gitignore` to avoid committing unnecessary files:

```
.vscode/
.alcache/
.alpackages/
.snapshots/
.output/
*.app
rad.json
*.g.xlf
*.flf
TestResults.xml
```

> ✅ These exclusions ensure a clean Git history and focus on source files only.

---

## 🚀 How to Use This Template

1. **Clone or Fork** this repository
2. Open the folder in **Visual Studio Code**
3. Install the **AL Language extension**
4. Configure your `launch.json` and `app.json`
5. Start building your extension or customization!

---

## ✅ Best Practices

- Keep your symbols and build output **outside version control**
- Use `.g.xlf` for translations, but track them separately if needed
- Run automated tests and keep `TestResults.xml` clean in production branches

---

## 🛡️ License

This template is provided "as is" for internal or open-source use. Always validate license compatibility if redistributing.

---

## 📬 Feedback & Contributions

Feel free to **open an issue** or **submit a pull request** if you have suggestions or improvements for this template.
